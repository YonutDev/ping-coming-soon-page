This is for developers.

The website is coded in Pug & SCSS. If you are a developer, drag and drop the files in the primary location of the website,
if not, delete this .zip.

Thanks!